package com.qa.opencart.constants;

public class AppConstants {
	
	
	public static final String HOME_PAGE_TITLE = "Your Store";
	
	public static final String LOGIN_PAGE_TITLE = "Account Login";


}
